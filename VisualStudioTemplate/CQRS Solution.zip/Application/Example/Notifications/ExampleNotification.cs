using MediatR;

namespace Application.Example.Notifications
{
    public class ExampleNotification : INotification { }
}
