﻿namespace Application;

public static class AssemblyMark
{
    
}
