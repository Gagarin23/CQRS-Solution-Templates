using MediatR;

namespace Application.Features.V1.Example.Notifications
{
    public class ExampleNotification : INotification { }
}
