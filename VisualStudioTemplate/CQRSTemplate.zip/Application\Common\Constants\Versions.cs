﻿namespace Application.Common.Constants;

public class Versions
{
    public const string CurrentVersion = V1;

    public const string V1 = "1.0";
}
