﻿namespace Api.Filters;

public class ProblemDetail
{
    public int? ErrorCode { get; set; }
    public string ErrorMessage { get; set; }
}
