using MediatR;

namespace $safeprojectname$.Example.Streams
{
    public class StreamQuery : IStreamRequest<int>
    {
        public int Count { get; set; }
    }
}
