using MediatR;

namespace $safeprojectname$.Example.Queries
{
    public class OkQuery : IRequest<string>
    {
        public string TestMsg { get; set; }
    }
}
