using MediatR;

namespace $safeprojectname$.Example.Notifications
{
    public class ExampleNotification : INotification { }
}
