﻿using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Common.Interfaces;

public interface IPooledDbContextFactory
{
    Task<IDatabaseContext> CreateContextAsync(CancellationToken cancellationToken = default);
    IDatabaseContext CreateContext();
}
